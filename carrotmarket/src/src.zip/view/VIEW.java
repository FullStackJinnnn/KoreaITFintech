package view;

import java.util.Scanner;

public abstract class VIEW {
	protected Scanner sc;

	public VIEW() {
		sc = new Scanner(System.in);
	}
}
