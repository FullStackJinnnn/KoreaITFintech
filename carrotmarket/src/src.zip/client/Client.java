package client;

import ctrl.CTRL;

public class Client {
	public static void main(String[] args) {
		CTRL app=new CTRL();
		app.start();
	}
}
