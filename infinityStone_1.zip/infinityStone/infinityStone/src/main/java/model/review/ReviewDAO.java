package model.review;

public class ReviewDAO {

}
