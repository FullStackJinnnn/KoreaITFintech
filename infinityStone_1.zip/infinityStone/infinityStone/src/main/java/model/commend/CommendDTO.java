package model.commend;

public class CommendDTO {

	private int boardNum;
	private int memberNum;
	private int commendCount;

	public int getMemberNum() {
		return memberNum;
	}

	public void setMemberNum(int memberNum) {
		this.memberNum = memberNum;
	}

	public int getCommendCount() {
		return commendCount;
	}

	public void setCommendCount(int commendCount) {
		this.commendCount = commendCount;
	}

	@Override
	public String toString() {
		return "CommendDTO [boardNum=" + boardNum + ", memberNum=" + memberNum + ", commendCount=" + commendCount + "]";
	}

}
