package controller.front;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.common.FindIdAction;
import controller.common.FindIdPageAction;
import controller.common.FindPwPageAction;
import controller.common.JoinAction;
import controller.common.JoinPageAction;
import controller.common.LoginAction;
import controller.common.LoginPageAction;
import controller.common.LogoutAction;
import controller.common.MainAction;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FrontController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String uri = request.getRequestURI();
		String cp = request.getContextPath();

		String action = uri.substring(cp.length());

		System.out.println("[로그]" + uri);

		ActionForward forward = null;
		if (action.equals("/main.do")) { // 메인페이지로 이동

			forward = new MainAction().execute(request, response);

		} else if (action.equals("/joinPage.do")) { // 회원가입 페이지로 이동

			forward = new JoinPageAction().execute(request, response);

		} else if (action.equals("/join.do")) { // 회원가입

			forward = new JoinAction().execute(request, response);

		} else if (action.equals("/loginPage.do")) { // 로그인 페이지로 이동

			forward = new LoginPageAction().execute(request, response);

		} else if (action.equals("/login.do")) { // 로그인

			forward = new LoginAction().execute(request, response);

		} else if (action.equals("/logout.do")) { // 로그아웃

			forward = new LogoutAction().execute(request, response);

		} else if (action.equals("/findIdPage.do")) { // 아이디 찾기 페이지로 이동

			forward = new FindIdPageAction().execute(request, response);

		} else if (action.equals("/findId.do")) { // 아이디 찾기

			forward = new FindIdAction().execute(request, response);

		} else if (action.equals("/findPwPage.do")) { // 비밀번호 찾기 페이지로 이동

			forward = new FindPwPageAction().execute(request, response);

		} else if (action.equals("/findPw.do")) { // 비밀번호 찾기

			forward = new FindPwAction().execute(request, response);

		} else if (action.equals("/changePwPage.do")) { // 비밀번호 변경 페이지로 이동

			forward = new ChangePwPageAction().execute(request, response);

		} else if (action.equals("/changePw.do")) { // 비밀번호 변경

			forward = new ChangePwAction().execute(request, response);

		} else if (action.equals("/checkPwPage.do")) { // 비밀번호 확인 페이지로 이동

			forward = new CheckPwPageAction().execute(request, response);

		} else if (action.equals("/checkPw.do")) { // 비밀번호 확인

			forward = new CheckPwAction().execute(request, response);

		} else if (action.equals("/myPage.do")) { // 마이페이지로 이동

			forward = new MyPagePageAction().execute(request, response);

		} else if (action.equals("/memberPage.do")) { // 유저 페이지로 이동

			forward = new MemberPageAction().execute(request, response);

		} else if (action.equals("/changeNickname.do")) { // 닉네임 변경

			forward = new ChangeNickNameAction().execute(request, response);

		} else if (action.equals("/changePh.do")) { // 전화번호 변경

			forward = new ChangePhAction().execute(request, response);

		} else if (action.equals("/myBoardSelectAllPage.do")) { // 내가 작성한 글 목록보기 페이지로 이동

			forward = new MyboardSelectAllPageAction().execute(request, response);

		} else if (action.equals("/myBoardSelectOnePage.do")) { // 내가 작성한 글 상세보기 페이지로 이동

			forward = new MyBoardSelectOnePageAction().execute(request, response);

		} else if (action.equals("/deleteAccount.do")) { // 회원 탈퇴

			forward = new DeleteAccountAction().execute(request, response);

		} else if (action.equals("/memberBoardSelectAllPage.do")) { // 유저가 작성한 글 목록보기 페이지로 이동

			forward = new MemberBoardSelectAllPageAction().execute(request, response);

		} else if (action.equals("/memberBoardSelectOnePage.do")) { // 유저가 작성한 글 상세보기 페이지로 이동

			forward = new MemberBoardSelectOneAction().execute(request, response);

		} else if (action.equals("/sellBoardSelectAllPage.do")) { // 카메라 판매글 카테고리 페이지로 이동

			forward = new SellBoardSelectAllPageAction().execute(request, response);

		} else if (action.equals("/sellBoardSelectOnePage.do")) { // 카메라 판매글 상세보기 페이지로 이동

			forward = new SellBoardSelectOneAction().execute(request, response);

		} else if (action.equals("/sellBoardReviewPage.do")) { // 카메라 판매글 댓글 상세보기 페이지로 이동

			forward = new SellBoardReviewPageAction().execute(request, response);

		} else if (action.equals("/cameraReviewSelectAllPage.do")) { // 카메라 리뷰글 카테고리 페이지로 이동

			forward = new CameraReviewSelectAllAction().execute(request, response);

		} else if (action.equals("/cameraReviewSelectOnePage.do")) { // 카메라 리뷰글 상세보기 페이지로 이동

			forward = new CameraReviewSelctOnePageAction().execute(request, response);

		} else if (action.equals("/cameraReviewReviewPage.do")) { // 카메라 리뷰글 댓글 상세보기 페이지로 이동

			forward = new CameraReviewReviewPageAction().execute(request, response);

		} else if (action.equals("/freeBoardSelectAllPage.do")) { // 자유게시판 카테고리 페이지로 이동

			forward = new FreeBoardSelectAllPageAction().execute(request, response);

		} else if (action.equals("/freeBoardSelectOnePage.do")) { // 자유게시판 상세보기 페이지로 이동

			forward = new FreeBoardSelectOnePageAction().execute(request, response);

		} else if (action.equals("/freeBoardReviewSelectOnePage.do")) { // 자유게시판 댓글 상세보기 페이지로 이동

			forward = new FreeBoardReviewSelectOnePageAction().execute(request, response);

		} else if (action.equals("/reviewWrite.do")) { // 댓글 입력

			forward = new ReviewWriteAction().execute(request, response);

		} else if (action.equals("/reviewUpdate.do")) { // 댓글 수정

			forward = new ReviewUpdateAction().execute(request, response);

		} else if (action.equals("/reviewDelete.do")) { // 댓글 삭제

			forward = new ReviewDeleteAction().execute(request, response);

		} else if (action.equals("/sellBoardWritePage.do")) { // 카매라 판매글 작성 페이지로 이동

			forward = new SellBoardWritePageAction().execute(request, response);

		} else if (action.equals("/sellBoardWrite.do")) { // 카메라 판매글 작성

			forward = new SellBoardWriteAction().execute(request, response);

		} else if (action.equals("/sellBoardUpdatePage.do")) { // 카메라 판매글 수정 페이지로 이동

			forward = new SellBoardUpdatePageAction().execute(request, response);

		} else if (action.equals("/sellBoardUpdate.do")) { // 카메라 판매글 수정

			forward = new SellBoardUpdateAction().execute(request, response);

		} else if (action.equals("/cameraReviewWritePage.do")) { // 카메라 리뷰글 작성 페이지로 이동

			forward = new CameraReviewWritePageAction().execute(request, response);

		} else if (action.equals("/cameraReviewWrite.do")) { // 카메라 리뷰글 작성

			forward = new CameraReviewWriteAction().execute(request, response);

		} else if (action.equals("/cameraReviewUpdatePage.do")) { // 카메라 리뷰글 수정 페이지로 이동

			forward = new CameraReviewUpdatePageAction().execute(request, response);

		} else if (action.equals("/cameraReviewUpdate.do")) { // 카메라 리뷰글 수정

			forward = new CameraReviewUpdateAction().execute(request, response);

		} else if (action.equals("/freeBoardWritePage.do")) { // 자유 게시판 글 작성 페이지로 이동

			forward = new FreeBoardWritePageAction().execute(request, response);

		} else if (action.equals("/freeBoardWrite.do")) { // 자유 게시판 글 작성

			forward = new FreeBoardWriteAction().execute(request, response);

		} else if (action.equals("/freeBoardUpdatePage.do")) { // 자유 게시판 글 수정 페이지로 이동

			forward = new FreeBoardUpdatePageAction().execute(request, response);

		} else if (action.equals("/freeBoardUpdate.do")) { // 자유 게시판 글 수정

			forward = new FreeBoardUpdateAction().execute(request, response);

		}

		if (forward == null) {
			forward.setPath("error/error.jsp");
			// 에러페이지 이동
		}

		if (forward.isRedirect()) {
			response.sendRedirect(forward.getPath());
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
			dispatcher.forward(request, response);
		}

	}

}
