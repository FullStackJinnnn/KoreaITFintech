package model.board;

public class BoardDTO {

}

// test 용