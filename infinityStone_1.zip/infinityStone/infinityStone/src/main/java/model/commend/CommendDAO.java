package model.commend;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class CommendDAO {

	private Connection conn; // DB와의 연결을 담당
	private PreparedStatement pstmt; // CRUD 수행을 담당

	private static final String SELECTALL = "";
	private static final String SELECTONE = "";
	private static final String INSERT = "";
	private static final String UPDATE = "";
	private static final String DELETE = "";

	public ArrayList<CommendDTO> selectAll(CommendDTO rDTO) {
		ArrayList<CommendDTO> datas = new ArrayList<CommendDTO>();

		return datas;
	}

	public CommendDTO selectOne(CommendDTO rDTO) {
		CommendDTO data = null;

		return data;
	}

	public boolean update(CommendDTO rDTO) {

		return false;

	}

	private boolean delete(CommendDTO rDTO) {

		return false;
	}

	private boolean insert(CommendDTO rDTO) {

		return false;
	}

}
